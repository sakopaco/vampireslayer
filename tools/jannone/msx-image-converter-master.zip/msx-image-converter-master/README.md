[![Build Status](https://travis-ci.org/jannone/msx-image-converter.svg?branch=master)](https://travis-ci.org/jannone/msx-image-converter)

# msx-image-converter

MSX image converter based on Leandro Correia's source code, in Typescript

Note: this is alpha quality software. Use it at your own risk
