#! /bin/sh

sjasm -s variables.asm

sjasm -s vs.asm

